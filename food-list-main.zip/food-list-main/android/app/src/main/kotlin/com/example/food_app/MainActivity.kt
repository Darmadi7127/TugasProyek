package com.example.food_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
